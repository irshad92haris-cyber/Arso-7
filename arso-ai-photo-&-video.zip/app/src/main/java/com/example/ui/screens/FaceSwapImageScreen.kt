package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Face
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ArsoViewModel
import com.example.ui.DrawableResolver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FaceSwapImageScreen(
    viewModel: ArsoViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToDetail: () -> Unit
) {
    val isProcessing by viewModel.isProcessing.collectAsState()
    val progress by viewModel.processingProgress.collectAsState()
    val logText by viewModel.processingLog.collectAsState()

    var projectTitle by remember { mutableStateOf("") }
    
    // Choose presets
    val presets = listOf(
        viewModel.sampleImageMan to "Handsome Man Portrait",
        viewModel.sampleImageWoman to "Elegant Woman Portrait"
    )

    var selectedSource by remember { mutableStateOf(presets[0].first) }
    var selectedTarget by remember { mutableStateOf(presets[1].first) }

    // Compare slider state
    var sliderPosition by remember { mutableStateOf(0.5f) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Face Swap (Image)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("swap_image_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (isProcessing) {
            AIProcessingView(progress = progress, logText = logText)
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
                    .testTag("swap_image_main_scroll"),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Interactive Comparison slider
                Text(
                    text = "Before/After Live Preview (Drag slider below)",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.DarkGray)
                        .testTag("interactive_slider_box")
                ) {
                    // Original image (Left side or Full Base)
                    Image(
                        painter = painterResource(id = DrawableResolver.resolve(selectedSource)),
                        contentDescription = "Original",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Swapped Image (Overlayed with fraction)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction = sliderPosition)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                    ) {
                        Image(
                            painter = painterResource(id = DrawableResolver.resolve(selectedTarget)),
                            contentDescription = "Swapped Result",
                            modifier = Modifier
                                .fillMaxWidth(fraction = 1f / sliderPosition) // Adjust to prevent distortion
                                .fillMaxHeight(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    // Vertical partition line
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(4.dp)
                            .align(Alignment.CenterStart)
                            .offset(x = (270 * sliderPosition).dp) // simplistic approximation
                            .background(MaterialTheme.colorScheme.primary)
                    )

                    // Labels
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                            .background(Color.Black.copy(0.7f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Target Face", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .background(Color.Black.copy(0.7f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Source Face", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Slider element
                Slider(
                    value = sliderPosition,
                    onValueChange = { sliderPosition = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("slider_interact"),
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )

                // Title Input
                Text(
                    text = "Project Name",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                OutlinedTextField(
                    value = projectTitle,
                    onValueChange = { projectTitle = it },
                    placeholder = { Text("E.g., Glamour Swap") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_title_input"),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                // Choose Source & Target Faces
                Text(
                    text = "Source Target Setup",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Source Portrait", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            presets.forEach { (img, label) ->
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(
                                            width = if (selectedSource == img) 3.dp else 1.dp,
                                            color = if (selectedSource == img) MaterialTheme.colorScheme.primary else Color.Gray,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { selectedSource = img }
                                ) {
                                    Image(
                                        painter = painterResource(id = DrawableResolver.resolve(img)),
                                        contentDescription = label,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Target Photo Frame", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            presets.forEach { (img, label) ->
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(
                                            width = if (selectedTarget == img) 3.dp else 1.dp,
                                            color = if (selectedTarget == img) MaterialTheme.colorScheme.primary else Color.Gray,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { selectedTarget = img }
                                ) {
                                    Image(
                                        painter = painterResource(id = DrawableResolver.resolve(img)),
                                        contentDescription = label,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // Run Action Button
                Button(
                    onClick = {
                        viewModel.runFaceSwapImage(
                            title = projectTitle,
                            sourceImage = selectedSource,
                            targetImage = selectedTarget
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("run_face_swap_button"),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Synthesize Face Swap", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun AIProcessingView(
    progress: Float,
    logText: String
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)) // Sleek space background
            .padding(24.dp)
            .testTag("ai_processing_root"),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(150.dp)
        ) {
            CircularProgressIndicator(
                progress = { progress },
                modifier = Modifier.size(130.dp),
                color = MaterialTheme.colorScheme.primary,
                strokeWidth = 6.dp,
                trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
            )
            Icon(
                Icons.Filled.AutoAwesome,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(40.dp))

        Text(
            text = "AI RENDER CO-PROCESSOR ACTIVE",
            color = Color.LightGray,
            letterSpacing = 1.5.sp,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "${(progress * 100).toInt()}% Rendered",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 28.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Live Log status bar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(0.3f), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(
                containerColor = Color.Black.copy(alpha = 0.4f)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = logText,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
